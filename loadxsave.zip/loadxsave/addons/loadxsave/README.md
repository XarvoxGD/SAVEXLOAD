Hola, mi nombre es Xarvox, hice este plugin para hacerte más fácil el guardar y cargar
existen 2 nodos nuevos, LoadButton y SaveButton, cada uno pues tiene su función, puedes agregarle
texto si quieres, lo único que hace este nodo es llamar a loadxsavebyx.load_game (SaveButton) 
y loadxsavebyx.save_game (LoadButton) osea que puedes llamarlo desde otro nodo, no se, un Area2D
con la señal body entered o algo así, no necesitas darme créditos en ningún caso ya que es un
sistema muy básico. 
Además puedes agregar más variables a guardar en el singleton del plugin.
Perdon si notas que la escena de ejemplo se queda trabada, no se cual sea el error, pero en el sistema 
de guardado no es.
Disfruta :D

Hello, my name is Xarvox, I made this plugin to make it easier for you to save and load There
are 2 new nodes, LoadButton and SaveButton, each one has its function, you can add to it text 
if you want, the only thing this node does is call loadxsavebyx.load_game(SaveButton) and 
loadxsavebyx.save_game (LoadButton) I mean you can call it from another node, 
I don't know, an Area2D with the body entered signal or something like that, you don't need 
to give me credits in any case since it is a very basic system. You can also add more variables to 
save in the plugin's singleton. Sorry if you notice that the example scene is stuck, I don't know 
what the error is, but it's not in the save system. Enjoy :D
